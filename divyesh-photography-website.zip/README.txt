# Divyesh Photography Website

A responsive, premium photography portfolio designed for GitHub Pages.

## Upload to GitHub Pages

1. Replace your existing `index.html` with the included `index.html`.
2. Upload `style.css` and `script.js` to the same folder.
3. Commit and push the changes.
4. GitHub Pages will automatically rebuild the site.

## Important customization

Open `index.html` and replace:
- `your@email.com` with your real email.
- `@yourinstagram` with your Instagram username/link.
- `Your City, India` with your location.
- The text in the About/Services sections with your exact information.

## Replace the demo photography

The site currently uses high-quality remote Unsplash images so it works immediately.

For your own images, upload an `images` folder and change image URLs such as:

`src="images/portrait-01.jpg"`

Recommended images:
- hero.jpg
- about.jpg
- portrait-01.jpg
- portrait-02.jpg
- couple-01.jpg
- event-01.jpg
- landscape-01.jpg
- landscape-02.jpg

No framework or build step is required.
